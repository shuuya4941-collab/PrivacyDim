package com.privacydim.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.util.concurrent.Executors

/**
 * خدمة أمامية تفتح الكاميرا الأمامية بشكل مستمر وتحلل الإطارات لمعرفة هل هناك وجه ينظر للشاشة.
 * تستخدم LifecycleService لأن CameraX يحتاج LifecycleOwner.
 * إذا لم يُكتشف وجه لمدة أطول من المهلة المحددة، يتم تفعيل طبقة التعتيم.
 */
class FaceDetectionService : LifecycleService() {

    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile private var lastFaceSeenAtMs: Long = System.currentTimeMillis()

    private val detectorOptions = FaceDetectorOptions.Builder()
        .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
        .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_NONE)
        .build()
    private val faceDetector = FaceDetection.getClient(detectorOptions)

    private val watchdog = object : Runnable {
        override fun run() {
            val timeoutMs = Prefs.getFaceTimeoutMs(applicationContext)
            val elapsed = System.currentTimeMillis() - lastFaceSeenAtMs
            OverlayController.faceTriggerActive = elapsed > timeoutMs
            OverlayController.refresh(applicationContext)
            mainHandler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        startCamera()
        mainHandler.post(watchdog)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        return START_STICKY
    }

    private fun startAsForeground() {
        val channelId = "privacy_dim_face_channel"
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "Privacy Dim - كشف الوجه", NotificationManager.IMPORTANCE_MIN
            )
            manager.createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Privacy Dim نشط")
            .setContentText("تتم مراقبة وجود الوجه أمام الشاشة")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
        } else {
            startForeground(1, notification)
        }
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()

            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()

            analysis.setAnalyzer(cameraExecutor) { imageProxy -> analyzeFrame(imageProxy) }

            val selector = CameraSelector.DEFAULT_FRONT_CAMERA

            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, selector, analysis)
            } catch (_: Exception) {
                // فشل ربط الكاميرا (مثلاً: لا توجد كاميرا أمامية) — نكتفي بالصمت هنا
            }
        }, ContextCompat.getMainExecutor(this))
    }

    @androidx.annotation.OptIn(androidx.camera.core.ExperimentalGetImage::class)
    private fun analyzeFrame(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            imageProxy.close()
            return
        }
        val inputImage = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)

        faceDetector.process(inputImage)
            .addOnSuccessListener { faces ->
                if (faces.isNotEmpty()) {
                    lastFaceSeenAtMs = System.currentTimeMillis()
                }
            }
            .addOnCompleteListener {
                imageProxy.close()
            }
    }

    override fun onDestroy() {
        super.onDestroy()
        mainHandler.removeCallbacks(watchdog)
        cameraExecutor.shutdown()
        faceDetector.close()
        OverlayController.faceTriggerActive = false
        OverlayController.refresh(applicationContext)
    }

    override fun onBind(intent: Intent): IBinder? {
        super.onBind(intent)
        return null
    }
}
