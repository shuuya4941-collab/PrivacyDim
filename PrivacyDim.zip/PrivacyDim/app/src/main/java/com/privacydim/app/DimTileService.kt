package com.privacydim.app

import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * زر Quick Settings يظهر في لوحة الإشعارات (يعمل مع لوحة تحكم سامسونج One UI أيضًا،
 * لأنها تبني فوق نفس واجهة Android القياسية TileService).
 * إضافته للوحة تتم يدويًا من المستخدم بالسحب من قائمة "تعديل" في لوحة الإشعارات.
 */
class DimTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        updateTile()
    }

    override fun onClick() {
        super.onClick()
        val newState = !Prefs.isMasterEnabled(this)
        Prefs.setMasterEnabled(this, newState)

        if (newState) {
            startFaceServiceIfNeeded()
        } else {
            stopService(Intent(this, FaceDetectionService::class.java))
            OverlayController.appTriggerActive = false
            OverlayController.faceTriggerActive = false
        }
        OverlayController.refresh(this)
        updateTile()
    }

    private fun startFaceServiceIfNeeded() {
        if (!Prefs.isFaceDimEnabled(this)) return
        val intent = Intent(this, FaceDetectionService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun updateTile() {
        val tile = qsTile ?: return
        val enabled = Prefs.isMasterEnabled(this)
        tile.state = if (enabled) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = "Privacy Dim"
        tile.subtitle = if (enabled) "مفعّل" else "متوقف"
        tile.updateTile()
    }
}
