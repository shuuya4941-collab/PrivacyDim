package com.privacydim.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * تُشغَّل تلقائيًا بعد أن يفعّلها المستخدم يدويًا من: الإعدادات > إمكانية الوصول > Privacy Dim.
 * تراقب حدث تغيّر النافذة النشطة (فتح تطبيق جديد للمقدمة) وتقارنه بقائمة الحزم المستهدفة.
 */
class AppWatcherAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val packageName = event?.packageName?.toString() ?: return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return

        val masterEnabled = Prefs.isMasterEnabled(this)
        val appDimEnabled = Prefs.isAppDimEnabled(this)
        val targets = Prefs.getTargetPackages(this)

        OverlayController.appTriggerActive =
            masterEnabled && appDimEnabled && targets.contains(packageName)

        OverlayController.refresh(this)
    }

    override fun onInterrupt() {
        OverlayController.appTriggerActive = false
        OverlayController.refresh(this)
    }
}
