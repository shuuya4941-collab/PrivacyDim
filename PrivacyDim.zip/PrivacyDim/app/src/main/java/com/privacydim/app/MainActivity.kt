package com.privacydim.app

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.privacydim.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val cameraPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted && Prefs.isFaceDimEnabled(this) && Prefs.isMasterEnabled(this)) {
                startFaceService()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.editTargetPackage.setText(Prefs.getTargetPackages(this).firstOrNull() ?: "")
        binding.switchAppDim.isChecked = Prefs.isAppDimEnabled(this)
        binding.switchFaceDim.isChecked = Prefs.isFaceDimEnabled(this)

        binding.btnOverlayPermission.setOnClickListener {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }

        binding.btnAccessibilitySettings.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        binding.btnSave.setOnClickListener {
            val pkg = binding.editTargetPackage.text.toString().trim()
            Prefs.setTargetPackages(this, if (pkg.isNotEmpty()) setOf(pkg) else emptySet())
            Prefs.setAppDimEnabled(this, binding.switchAppDim.isChecked)
            Prefs.setFaceDimEnabled(this, binding.switchFaceDim.isChecked)

            if (binding.switchFaceDim.isChecked) {
                ensureCameraPermissionThenStart()
            }
            binding.tvStatus.text = "تم الحفظ ✔"
        }

        binding.btnToggleMaster.setOnClickListener {
            val newState = !Prefs.isMasterEnabled(this)
            Prefs.setMasterEnabled(this, newState)
            if (newState) {
                ensureCameraPermissionThenStart()
            } else {
                stopService(Intent(this, FaceDetectionService::class.java))
                OverlayController.appTriggerActive = false
                OverlayController.faceTriggerActive = false
                OverlayController.refresh(this)
            }
            refreshStatusText()
        }

        refreshStatusText()
    }

    private fun ensureCameraPermissionThenStart() {
        if (!Prefs.isFaceDimEnabled(this)) return
        val granted = checkSelfPermission(android.Manifest.permission.CAMERA) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
        if (granted) startFaceService() else cameraPermissionLauncher.launch(android.Manifest.permission.CAMERA)
    }

    private fun startFaceService() {
        val intent = Intent(this, FaceDetectionService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun refreshStatusText() {
        val master = Prefs.isMasterEnabled(this)
        val overlayOk = OverlayController.hasOverlayPermission(this)
        binding.tvStatus.text = buildString {
            append(if (master) "الحالة: مفعّل ✅\n" else "الحالة: متوقف ⏸️\n")
            append(if (overlayOk) "صلاحية العرض فوق التطبيقات: ممنوحة\n" else "⚠️ يجب منح صلاحية العرض فوق التطبيقات\n")
            append("لا تنسَ تفعيل خدمة إمكانية الوصول من الإعدادات لمراقبة التطبيقات.")
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatusText()
    }
}
