package com.privacydim.app

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager

/**
 * مسؤول عن إضافة/إزالة طبقة تعتيم فوق كل التطبيقات.
 * لا تحجب اللمس (FLAG_NOT_TOUCHABLE) حتى يبقى الهاتف قابلاً للاستخدام أثناء التعتيم البصري فقط.
 */
object OverlayController {

    private var overlayView: View? = null
    private var windowManager: WindowManager? = null

    // حالتان مستقلتان يتحكمان في ظهور الطبقة: بسبب تطبيق معيّن، أو بسبب غياب الوجه
    @Volatile var appTriggerActive: Boolean = false
    @Volatile var faceTriggerActive: Boolean = false

    fun hasOverlayPermission(context: Context): Boolean {
        return Settings.canDrawOverlays(context)
    }

    /** يعيد تقييم ما إذا كانت الطبقة يجب أن تظهر أو تختفي بناءً على الحالتين */
    @Synchronized
    fun refresh(context: Context) {
        val shouldShow = Prefs.isMasterEnabled(context) && (appTriggerActive || faceTriggerActive)
        if (shouldShow) show(context) else hide()
    }

    @Synchronized
    private fun show(context: Context) {
        if (overlayView != null) return
        if (!hasOverlayPermission(context)) return

        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val alphaPercent = Prefs.getDimAlphaPercent(context).coerceIn(0, 100)
        val alphaInt = (alphaPercent * 255 / 100)

        val view = View(context.applicationContext).apply {
            setBackgroundColor(Color.argb(alphaInt, 0, 0, 0))
        }

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

        try {
            wm.addView(view, params)
            overlayView = view
        } catch (e: Exception) {
            overlayView = null
        }
    }

    @Synchronized
    private fun hide() {
        val view = overlayView ?: return
        try {
            windowManager?.removeView(view)
        } catch (_: Exception) {
        } finally {
            overlayView = null
        }
    }
}
