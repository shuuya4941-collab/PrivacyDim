package com.privacydim.app

import android.content.Context

/**
 * تخزين مركزي لكل إعدادات التطبيق، تستخدمه كل الخدمات (Accessibility, Face, Tile, Activity)
 */
object Prefs {
    private const val FILE = "privacy_dim_prefs"

    private const val KEY_MASTER_ENABLED = "master_enabled"      // مفتاح التشغيل العام (من زر Quick Settings)
    private const val KEY_APP_DIM_ENABLED = "app_dim_enabled"    // تفعيل التعتيم عند فتح تطبيق معين
    private const val KEY_FACE_DIM_ENABLED = "face_dim_enabled"  // تفعيل التعتيم عند عدم وجود وجه
    private const val KEY_TARGET_PACKAGES = "target_packages"    // أسماء حزم التطبيقات المستهدفة (مفصولة بفاصلة)
    private const val KEY_FACE_TIMEOUT_MS = "face_timeout_ms"    // مدة السماح بدون وجه قبل التعتيم
    private const val KEY_DIM_ALPHA = "dim_alpha"                 // شدة التعتيم 0..100

    private fun prefs(context: Context) =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun isMasterEnabled(context: Context) =
        prefs(context).getBoolean(KEY_MASTER_ENABLED, false)

    fun setMasterEnabled(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_MASTER_ENABLED, value).apply()
    }

    fun isAppDimEnabled(context: Context) =
        prefs(context).getBoolean(KEY_APP_DIM_ENABLED, true)

    fun setAppDimEnabled(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_APP_DIM_ENABLED, value).apply()
    }

    fun isFaceDimEnabled(context: Context) =
        prefs(context).getBoolean(KEY_FACE_DIM_ENABLED, false)

    fun setFaceDimEnabled(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_FACE_DIM_ENABLED, value).apply()
    }

    fun getTargetPackages(context: Context): Set<String> {
        val raw = prefs(context).getString(KEY_TARGET_PACKAGES, "") ?: ""
        return raw.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
    }

    fun setTargetPackages(context: Context, packages: Set<String>) {
        prefs(context).edit().putString(KEY_TARGET_PACKAGES, packages.joinToString(",")).apply()
    }

    fun getFaceTimeoutMs(context: Context) =
        prefs(context).getLong(KEY_FACE_TIMEOUT_MS, 3000L)

    fun setFaceTimeoutMs(context: Context, value: Long) {
        prefs(context).edit().putLong(KEY_FACE_TIMEOUT_MS, value).apply()
    }

    fun getDimAlphaPercent(context: Context) =
        prefs(context).getInt(KEY_DIM_ALPHA, 85)

    fun setDimAlphaPercent(context: Context, value: Int) {
        prefs(context).edit().putInt(KEY_DIM_ALPHA, value).apply()
    }
}
